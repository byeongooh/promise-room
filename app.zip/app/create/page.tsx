"use client"

import { useRouter } from "next/navigation"
import CreatePromiseForm from "@/components/create-promise-form"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Calendar } from "lucide-react"
import Link from "next/link"
import { useUser } from "@/lib/user-context"
import UserLogin from "@/components/user-login"

export default function CreatePage() {
  const router = useRouter()
  const { currentUser } = useUser()

  if (!currentUser) {
    return <UserLogin />
  }

  const handleCreatePromise = (promiseData: {
    title: string
    date: string
    time: string
    location: string
    penalty: string
    creator: string
    password: string
  }) => {
    // Generate a unique ID for the promise
    const promiseId = Date.now().toString()

    // Store promise data in sessionStorage
    sessionStorage.setItem(
      promiseId,
      JSON.stringify({
        ...promiseData,
        participants: [promiseData.creator],
      }),
    )

    // Navigate to promise page
    router.push(`/promise/${promiseId}`)
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <Link href="/">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            대시보드로 돌아가기
          </Button>
        </Link>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Calendar className="w-10 h-10 text-primary" />
            <h1 className="text-3xl font-bold">새로운 약속 만들기</h1>
          </div>
          <p className="text-muted-foreground">친구들과 함께할 약속을 생성하세요</p>
        </div>

        <CreatePromiseForm onCreate={handleCreatePromise} currentUser={currentUser} />
      </div>
    </div>
  )
}
