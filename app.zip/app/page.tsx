"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Calendar, Plus, LogOut } from "lucide-react"
import PromiseDashboard from "@/components/promise-dashboard"
import UserLogin from "@/components/user-login"
import { useUser } from "@/lib/user-context"

export interface Promise {
  id: string
  title: string
  date: string
  time: string
  location: string
  penalty: string
  creator: string
  participants: string[]
  password: string
}

export default function HomePage() {
  const router = useRouter()
  const [promises, setPromises] = useState<Promise[]>([])
  const { currentUser, logout } = useUser()

  useEffect(() => {
    const loadPromises = () => {
      const allPromises: Promise[] = []

      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i)
        if (key && !isNaN(Number(key))) {
          const data = sessionStorage.getItem(key)
          if (data) {
            try {
              const promise = JSON.parse(data)
              allPromises.push({ id: key, ...promise })
            } catch (e) {
              console.error("Failed to parse promise data", e)
            }
          }
        }
      }

      // Sort by date (newest first)
      allPromises.sort((a, b) => {
        const dateA = new Date(`${a.date} ${a.time}`)
        const dateB = new Date(`${b.date} ${b.time}`)
        return dateB.getTime() - dateA.getTime()
      })

      setPromises(allPromises)
    }

    if (currentUser) {
      loadPromises()

      // Reload promises when window gains focus (in case data changed)
      const handleFocus = () => loadPromises()
      window.addEventListener("focus", handleFocus)

      return () => window.removeEventListener("focus", handleFocus)
    }
  }, [currentUser])

  if (!currentUser) {
    return <UserLogin />
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Calendar className="w-10 h-10 text-primary" />
            <div>
              <h1 className="text-4xl font-bold">Promise Room</h1>
              <p className="text-muted-foreground">친구들과 함께하는 약속 관리</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">로그인:</p>
              <p className="font-semibold">{currentUser}</p>
            </div>
            <Button size="lg" onClick={() => router.push("/create")}>
              <Plus className="w-5 h-5 mr-2" />새 약속 만들기
            </Button>
            <Button variant="outline" size="lg" onClick={logout}>
              <LogOut className="w-5 h-5 mr-2" />
              로그아웃
            </Button>
          </div>
        </div>

        <PromiseDashboard promises={promises} currentUser={currentUser} />
      </div>
    </div>
  )
}
