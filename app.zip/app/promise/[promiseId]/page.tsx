"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import PromiseDetail from "@/components/promise-detail"
import JoinForm from "@/components/join-form"
import ParticipantList from "@/components/participant-list"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Trash2, Lock } from "lucide-react"
import Link from "next/link"
import { useUser } from "@/lib/user-context"
import UserLogin from "@/components/user-login"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface PromiseData {
  title: string
  date: string
  time: string
  location: string
  penalty: string
  creator: string
  participants: string[]
  password: string
}

export default function PromisePage() {
  const params = useParams()
  const router = useRouter()
  const promiseId = params.promiseId as string
  const [promiseData, setPromiseData] = useState<PromiseData | null>(null)
  const { currentUser } = useUser()
  const [hasAccess, setHasAccess] = useState(false)
  const [passwordInput, setPasswordInput] = useState("")
  const [passwordError, setPasswordError] = useState(false)

  useEffect(() => {
    // Load promise data from sessionStorage
    const data = sessionStorage.getItem(promiseId)
    if (data) {
      const promise = JSON.parse(data)
      setPromiseData(promise)

      const isCreator = promise.creator === currentUser
      const isParticipant = promise.participants?.includes(currentUser)

      if (isCreator || isParticipant) {
        setHasAccess(true)
      }
    }
  }, [promiseId, currentUser])

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (promiseData && passwordInput === promiseData.password) {
      setHasAccess(true)
      setPasswordError(false)
    } else {
      setPasswordError(true)
    }
  }

  const handleAddParticipant = (name: string) => {
    if (!promiseData) return

    const updatedData = {
      ...promiseData,
      participants: [...promiseData.participants, name],
    }

    setPromiseData(updatedData)
    sessionStorage.setItem(promiseId, JSON.stringify(updatedData))
  }

  const handleDelete = () => {
    sessionStorage.removeItem(promiseId)

    // Remove from promises list
    const promisesData = sessionStorage.getItem("promises")
    if (promisesData) {
      const promises = JSON.parse(promisesData)
      const updatedPromises = promises.filter((p: any) => p.id !== promiseId)
      sessionStorage.setItem("promises", JSON.stringify(updatedPromises))
    }

    router.push("/")
  }

  if (!currentUser) {
    return <UserLogin />
  }

  if (!promiseData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">약속을 찾을 수 없습니다</p>
          <Link href="/">
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              대시보드로 돌아가기
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <Lock className="w-6 h-6 text-primary" />
              <CardTitle className="text-2xl">비밀번호 입력</CardTitle>
            </div>
            <CardDescription>이 약속은 비밀번호로 보호되어 있습니다. 비밀번호를 입력하세요.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">비밀번호</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="비밀번호를 입력하세요"
                  value={passwordInput}
                  onChange={(e) => {
                    setPasswordInput(e.target.value)
                    setPasswordError(false)
                  }}
                  autoFocus
                />
                {passwordError && <p className="text-sm text-destructive">비밀번호가 올바르지 않습니다</p>}
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1 bg-transparent"
                  onClick={() => router.push("/")}
                >
                  취소
                </Button>
                <Button type="submit" className="flex-1">
                  확인
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <div className="flex items-center justify-between mb-6">
          <Link href="/">
            <Button variant="ghost">
              <ArrowLeft className="w-4 h-4 mr-2" />
              대시보드로 돌아가기
            </Button>
          </Link>

          {promiseData.creator === currentUser && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm">
                  <Trash2 className="w-4 h-4 mr-2" />
                  약속 삭제
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>약속을 삭제하시겠습니까?</AlertDialogTitle>
                  <AlertDialogDescription>
                    이 작업은 되돌릴 수 없습니다. 약속과 모든 참여자 정보가 영구적으로 삭제됩니다.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>취소</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDelete}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    삭제
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        <PromiseDetail promise={promiseData} />

        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <JoinForm
            onJoin={handleAddParticipant}
            isParticipant={promiseData.participants.includes(currentUser || "")}
          />
          <ParticipantList participants={promiseData.participants} />
        </div>
      </div>
    </div>
  )
}
